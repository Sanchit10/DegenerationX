package freecell.model;

import static org.junit.Assert.*;

public class FreecellOperationsTest {

}